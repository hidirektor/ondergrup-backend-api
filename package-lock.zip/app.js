const express = require('express');
const app = express();
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const { Schema } = mongoose;

dotenv.config();

// MongoDB bağlantısını oluştur
function createConnection() {
    mongoose.connect(process.env.MONGO_URI, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    });
    return mongoose.connection;
}

const connection = createConnection();
connection.on('error', (err) => {
    console.error('Veritabanına bağlanılamadı:', err);
});
connection.once('open', () => {
    console.log('Veritabanına başarıyla bağlanıldı.');
});

app.use(express.json());

// Custom middleware
app.use((req, res, next) => {
    res.sendResponse = (status, data) => {
        const responseData = {
            success: status < 400,
            data,
        };
        res.status(status).json(responseData);
    };
    next();
});

// MongoDB şemasını tanımla
const userSchema = new Schema({
    UserType: String,
    UserID: String,
    Password: String,
    NameSurname: String,
    Email: String,
    CompanyName: String,
    Phone: String,
    ProfilePhoto: String,
});

const UserModel = mongoose.model('Users', userSchema);

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await UserModel.findOne({ UserID: username, Password: password });
        if (user) {
            res.sendResponse(200, { message: 'Giriş başarılı' });
        } else {
            res.sendResponse(401, { error: 'Geçersiz kullanıcı adı veya şifre' });
        }
    } catch (err) {
        console.error('Sorgu hatası:', err);
        res.sendResponse(500, { error: 'Sunucu hatası' });
    }
});

app.post('/api/register', async (req, res) => {
    const { UserType, UserID, Password, NameSurname, Email, CompanyName, Phone, ProfilePhoto } = req.body;

    try {
        await UserModel.create({
            UserType,
            UserID,
            Password,
            NameSurname,
            Email,
            CompanyName,
            Phone,
            ProfilePhoto,
        });
        res.sendResponse(200, { message: 'Kullanıcı başarıyla eklendi' });
    } catch (err) {
        console.error('Sorgu hatası:', err);
        res.sendResponse(500, { error: 'Sunucu hatası' });
    }
});

const port = 443;
app.listen(port, () => {
    console.log(`Sunucu çalışıyor, https://localhost:${port}`);
});

process.on('SIGINT', () => {
    connection.close((err) => {
        if (err) {
            console.error('Veritabanı bağlantısı kapatılamadı:', err);
        } else {
            console.log('Veritabanı bağlantısı başarıyla kapatıldı.');
        }
        process.exit(0);
    });
});
