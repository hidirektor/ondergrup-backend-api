const UserModel = require('../models/UserSchema');
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');
const Grid = require('gridfs-stream');

// Create GridFS connection
const conn = mongoose.connection;
Grid.mongo = mongoose.mongo;
let gfs;

conn.once('open', () => {
    gfs = Grid(conn.db);
    console.log('GridFS connection established.');
});

async function register(req, res) {
    const { UserType, UserName, Password, NameSurname, Email, CompanyName, Phone, ProfilePhoto } = req.body;

    try {
        const existingUser = await UserModel.findOne({ UserName });

        if (existingUser) {
            return res.sendResponse(400, { error: 'Bu kullanıcı adı zaten kullanılıyor' });
        }

        // Create a new user document
        const newUser = await UserModel.create({
            UserType,
            UserName,
            Password,
            NameSurname,
            Email,
            CompanyName,
            Phone,
        });

        // Move uploaded file to GridFS
        if (ProfilePhoto) {
            const sourcePath = ProfilePhoto;
            const fileName = UserName + '-profilephoto';

            const writestream = gfs.createWriteStream({
                filename: fileName,
                metadata: {
                    username: UserName,
                },
            });

            fs.createReadStream(sourcePath).pipe(writestream);

            // Update the user document with the file ID
            newUser.ProfilePhoto = writestream.id;
            await newUser.save();
        }

        res.sendResponse(200, { message: 'Kullanıcı başarıyla eklendi' });
    } catch (err) {
        console.error('Sorgu hatası:', err);
        res.sendResponse(500, { error: 'Sunucu hatası' });
    }
}

module.exports = register;
